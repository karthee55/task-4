export interface IAuthLogin {
  email: string;
  password: string;
}
