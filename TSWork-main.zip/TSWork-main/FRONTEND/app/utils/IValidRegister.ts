export interface IValidRegister {
  name: boolean;
  surname: boolean;
  phone: boolean;
  email: boolean;
  password: boolean;
  confirmPassword: boolean;
  github: boolean;
  cv: boolean;
}
