export type tokensType = {
  accessToken: string;
  refreshToken: string;
}